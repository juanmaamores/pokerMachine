package com.example.pokermachine;

import android.content.Context;
import java.util.ArrayList;
import java.util.Collections;

public class Mazo {
    private final ArrayList<Carta> cartas;
    private final String[] palos = {"Corazones", "Espadas", "Treboles", "Diamantes"};
    private final Context context; // Guardamos el contexto

    public Mazo(Context context) {
        this.context = context;
        cartas = new ArrayList<>();
        inicializarMazo();
    }

    private void inicializarMazo() {
        int index = 0;
        for (String palo : palos) {
            for (int valor = 1; valor <= 13; valor++) {
                int id = index + 1; // ID único para cada carta
                cartas.add(new Carta(id, valor, palo, context)); // Pasamos el contexto
                index++;
            }
        }
    }

    public Carta getCarta() {
        return cartas.remove(cartas.size() - 1);
    }

    public void mezclarCartas() {
        Collections.shuffle(cartas);
    }
}

