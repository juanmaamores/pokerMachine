package com.example.pokermachine;

import android.content.Context;

public class Carta {
    private final int id;
    private final int valor;
    private final String palo;
    private final int imagenRecurso; // Nuevo atributo para almacenar la imagen

    // Constructor con asignación del recurso de imagen
    public Carta(int id, int valor, String palo, Context context) {
        this.id = id;
        this.valor = valor;
        this.palo = palo;
        this.imagenRecurso = obtenerImagenRecurso(context);
    }

    public int getId() {
        return id;
    }

    public int getValor() {
        return valor;
    }

    public String getPalo() {
        return palo;
    }

    public int getImagenRecurso() {
        return imagenRecurso;
    }

    // Método privado para asignar la imagen basada en el ID de la carta
    private int obtenerImagenRecurso(Context context) {
        String nombreImagen = "carta_" + id; // Ejemplo: "carta_52"
        return context.getResources().getIdentifier(nombreImagen, "drawable", context.getPackageName());
    }
}

