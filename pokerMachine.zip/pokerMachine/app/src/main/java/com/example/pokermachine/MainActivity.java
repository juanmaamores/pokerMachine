package com.example.pokermachine;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    private String tipoMano;
    int record;
    //sonidos
    private SoundPool soundPool;
    private int sonidoIDsubir;
    private int sonidoIDrepartir;
    private int sonidoIDmano;
    private int sonidoIDnada;
    private int sonidoIDpremioGordo;
    private int sonidoIDpremio;
    private int sonidoIDcarta;
    //para la musica
    private MediaPlayer mediaPlayer;
    //De la interfáz
    private ImageView carta0;
    private ImageView carta1;
    private ImageView carta2;
    private ImageView carta3;
    private ImageView carta4;
    private ImageView valores;
    private Button repartir, subir, mano0, mano1, mano2, mano3, mano4;
    private TextView plataValor;
    private TextView tuApuesta;
    private TextView mensajeGanador;
    private TextView recordvista;
    private final int valor_ficha = 100;
    private int apuesta = 100;
    private int dinero = 9000;
    private int fichasApostadas = 1;
    //mazo
    private Mazo mazo;
    private final Carta[] cartas = new Carta[5];
    //jugada
    private int jugada = 0;
    //manos
    private boolean boolMano0 = false, boolMano1 = false, boolMano2 = false, boolMano3 = false, boolMano4 = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getApplicationContext();
        EdgeToEdge.enable(this);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.activity_main);
        View decorView = getWindow().getDecorView();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //record
        cargarRecord(); // Cargar récord al iniciar
        // Inicializa el reproductor con la canción en la carpeta raw
        mediaPlayer = MediaPlayer.create(this, R.raw.cancion);
        if (mediaPlayer != null) {
            mediaPlayer.setLooping(true);
            mediaPlayer.start();
            mediaPlayer.setVolume(0.25f, 0.25f); //volumen de la música al 10%
        }
        @SuppressLint("UseSwitchCompatOrMaterialCode") Switch musica = findViewById(R.id.switchmusica);

        musica.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                mediaPlayer.start();
            } else {
                mediaPlayer.pause();
            }
        });
        cargarRecord(); // Cargar récord al iniciar
        // Vincular vistas
        recordvista = findViewById(R.id.record_valor);
        recordvista.setText(String.valueOf(record));
        valores = findViewById(R.id.valores);
        carta0 = findViewById(R.id.carta0);
        carta1 = findViewById(R.id.carta1);
        carta2 = findViewById(R.id.carta2);
        carta3 = findViewById(R.id.carta3);
        carta4 = findViewById(R.id.carta4);
        repartir = findViewById(R.id.repartir);
        subir = findViewById(R.id.subir);
        findViewById(R.id.plataTexto);
        plataValor = findViewById(R.id.plataValor);
        plataValor.setText(String.valueOf(dinero));
        TextView valorFicha = findViewById(R.id.valorFicha);
        valorFicha.setText(String.valueOf(valor_ficha));
        tuApuesta = findViewById(R.id.tuApuesta);
        tuApuesta.setText(String.valueOf(apuesta));
        mensajeGanador = findViewById(R.id.mensajeGanador);
        mensajeGanador.setText("");
        //botones mano
        mano0 = findViewById(R.id.mano0);
        mano1 = findViewById(R.id.mano1);
        mano2 = findViewById(R.id.mano2);
        mano3 = findViewById(R.id.mano3);
        mano4 = findViewById(R.id.mano4);
        mano0.setEnabled(false);
        mano1.setEnabled(false);
        mano2.setEnabled(false);
        mano3.setEnabled(false);
        mano4.setEnabled(false);
        mano0.setTextColor(Color.BLACK); // Cambia el color del texto
        mano0.setBackgroundColor(Color.GRAY); // Cambia el fondo del botón
        mano1.setTextColor(Color.BLACK); // Cambia el color del texto
        mano1.setBackgroundColor(Color.GRAY); // Cambia el fondo del botón
        mano2.setTextColor(Color.BLACK); // Cambia el color del texto
        mano2.setBackgroundColor(Color.GRAY); // Cambia el fondo del botón
        mano3.setTextColor(Color.BLACK); // Cambia el color del texto
        mano3.setBackgroundColor(Color.GRAY); // Cambia el fondo del botón
        mano4.setTextColor(Color.BLACK); // Cambia el color del texto
        mano4.setBackgroundColor(Color.GRAY); // Cambia el fondo del botón
        // Configurar listeners para botones
        repartir.setOnClickListener(v -> repartirCartas());
        subir.setOnClickListener(v -> subirApuesta());
        //botones mano
        mano0.setOnClickListener(v -> setMano0());
        mano1.setOnClickListener(v -> setMano1());
        mano2.setOnClickListener(v -> setMano2());
        mano3.setOnClickListener(v -> setMano3());
        mano4.setOnClickListener(v -> setMano4());
        //sonidos
        soundPool = new SoundPool.Builder().setMaxStreams(1).build();
        sonidoIDsubir = soundPool.load(this, R.raw.sonidosubir, 1);
        sonidoIDmano = soundPool.load(this, R.raw.mano, 1);
        sonidoIDrepartir = soundPool.load(this, R.raw.repartir, 1);
        sonidoIDnada = soundPool.load(this, R.raw.nada, 1);
        sonidoIDpremio = soundPool.load(this, R.raw.premio, 1);
        sonidoIDpremioGordo = soundPool.load(this, R.raw.premio_gordo, 1);
        sonidoIDcarta = soundPool.load(this, R.raw.carta, 1); //este sonido tendría que ir acompañado con la animación.
    }

    private void actualizarDinero() {
        dinero -= apuesta;
        plataValor.setText(String.valueOf(dinero));
        if (dinero > record) {
            record = dinero;
            actualizarRecord(record);
            recordvista.setText(String.valueOf(record));
        }
    }

    // Método para guardar el récord en SharedPreferences
    private void actualizarRecord(int nuevoRecord) {
        SharedPreferences prefs = getSharedPreferences("JuegoPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt("Record", nuevoRecord);
        editor.apply(); // Guarda de forma asíncrona
    }

    // Método para cargar el récord al iniciar la aplicación
    private void cargarRecord() {
        SharedPreferences prefs = getSharedPreferences("JuegoPrefs", MODE_PRIVATE);
        // Usamos el valor por defecto 0 en caso de que no exista un récord guardado
        record = prefs.getInt("Record", 0);
        Log.d("GameDebug", "Record loaded: " + record);
        // Asegúrate de que la vista se inicialice antes de intentar usarla
        if (recordvista != null) {
            recordvista.setText(String.valueOf(record));
            Log.d("GameDebug", "Record set on recordvista: " + record);
        } else {
            Log.e("GameDebug", "recordvista is null in cargarRecord");
        }
    }

   @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
       soundPool.release();
       getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mediaPlayer != null && !mediaPlayer.isPlaying()) {
            mediaPlayer.start();
        }
    }

    private void setMano0() {
        if(!boolMano0){
            boolMano0 = true;
            mano0.setTextColor(Color.BLACK);
            mano0.setBackgroundColor(Color.RED);
            soundPool.play(sonidoIDmano, 1f, 1f, 0, 0, 1f);
        } else {
            boolMano0 = false;
            mano0.setTextColor(Color.BLACK);
            mano0.setBackgroundColor(Color.rgb(100, 221, 23));
            soundPool.play(sonidoIDmano, 1f, 1f, 0, 0, 1f);
        }
        Log.d(TAG, "boolMano0" + boolMano0);
    }
    private void setMano1() {
        if(!boolMano1){
            boolMano1 = true;
            mano1.setTextColor(Color.BLACK);
            mano1.setBackgroundColor(Color.RED);
            soundPool.play(sonidoIDmano, 1f, 1f, 0, 0, 1f);
        } else {
            boolMano1 = false;
            mano1.setTextColor(Color.BLACK);
            mano1.setBackgroundColor(Color.rgb(100, 221, 23));
            soundPool.play(sonidoIDmano, 1f, 1f, 0, 0, 1f);
        }
        Log.d(TAG, "boolMano1" + boolMano1);
    }
    private void setMano2() {
        if(!boolMano2){
            boolMano2 = true;
            mano2.setTextColor(Color.BLACK);
            mano2.setBackgroundColor(Color.RED);
            soundPool.play(sonidoIDmano, 1f, 1f, 0, 0, 1f);
        } else {
            boolMano2 = false;
            mano2.setTextColor(Color.BLACK);
            mano2.setBackgroundColor(Color.rgb(100, 221, 23));
            soundPool.play(sonidoIDmano, 1f, 1f, 0, 0, 1f);
        }
        Log.d(TAG, "boolMano2" + boolMano2);
    }
    private void setMano3() {
        if(!boolMano3){
            boolMano3 = true;
            mano3.setTextColor(Color.BLACK);
            mano3.setBackgroundColor(Color.RED);
            soundPool.play(sonidoIDmano, 1f, 1f, 0, 0, 1f);
        } else {
            boolMano3 = false;
            mano3.setTextColor(Color.BLACK);
            mano3.setBackgroundColor(Color.rgb(100, 221, 23));
            soundPool.play(sonidoIDmano, 1f, 1f, 0, 0, 1f);
        }
        Log.d(TAG, "boolMano3" + boolMano3);
    }
    private void setMano4() {
        if(!boolMano4){
            boolMano4 = true;
            mano4.setTextColor(Color.BLACK);
            mano4.setBackgroundColor(Color.RED);
            soundPool.play(sonidoIDmano, 1f, 1f, 0, 0, 1f);
        } else {
            boolMano4 = false;
            mano4.setTextColor(Color.BLACK);
            mano4.setBackgroundColor(Color.rgb(100, 221, 23));
            soundPool.play(sonidoIDmano, 1f, 1f, 0, 0, 1f);
        }
        Log.d(TAG, "boolMano4" + boolMano4);
    }

    private static final String TAG = "JuegoCartas";

    private void repartirCartas() {
        ImageView[] imageViews = { carta0, carta1, carta2, carta3, carta4 };
        Button[] botonesMano = { mano0, mano1, mano2, mano3, mano4 };
        actualizarBoton(repartir, false, Color.BLACK, Color.GRAY);
        actualizarBoton(subir, false, Color.BLACK, Color.GRAY);
        if (jugada == 0) {
            soundPool.play(sonidoIDrepartir, 1f, 1f, 0, 0, 1f);
            actualizarBotonesMano(botonesMano, true, Color.rgb(100, 221, 23));
            mensajeGanador.setText("");
            actualizarDinero();
            mazo = new Mazo(this);
            mazo.mezclarCartas();
            repartirCartasAnimadas(imageViews, () -> {
                jugada++;
                Log.d(TAG, "Valor jugada:" + jugada);
                actualizarBoton(repartir, true, Color.BLACK, Color.YELLOW);
            });
        }
        if (jugada == 1) {
            Log.d(TAG, "Valor jugada:" + jugada);
            boolean[] boolManos = { boolMano0, boolMano1, boolMano2, boolMano3, boolMano4 };
            for (int i = 0; i < 5; i++) {
                if (!boolManos[i]) {
                    imageViews[i].setImageResource(R.drawable.cover);
                }
            }
            Handler handler = new Handler();
            int delay = 250;
            for (int i = 0; i < 5; i++) {
                final int index = i;
                if (!boolManos[i]) {
                    handler.postDelayed(() -> {
                        cartas[index] = mazo.getCarta();
                        soundPool.play(sonidoIDcarta, 1f, 1f, 0, 0, 1f);
                        imageViews[index].setImageResource(cartas[index].getImagenRecurso());
                        imageViews[index].setAlpha(0f);
                        imageViews[index].animate().alpha(1f).setDuration(250).start();
                    }, delay);
                    delay += 250;
                }
            }
            handler.postDelayed(() -> {
                for (Carta carta : cartas) {
                    Log.d(TAG, "Carta nro: " + carta.getId() + " valor: " + carta.getValor() + " palo: " + carta.getPalo());
                }
                jugada++;
                Log.d(TAG, "Valor jugada:" + jugada);
                if (jugada == 2) {
                    finalizarRonda(botonesMano, imageViews);
                } else {
                    actualizarBoton(repartir, true, Color.BLACK, Color.YELLOW);
                }
            }, delay + 250);
        }
    }

    private void repartirCartasAnimadas(ImageView[] imageViews, Runnable onComplete) {
        Handler handler = new Handler();
        int delay = 0;
        for (int i = 0; i < 5; i++) {
            final int index = i;
            delay += 250;
            handler.postDelayed(() -> {
                cartas[index] = mazo.getCarta();
                soundPool.play(sonidoIDcarta, 1f, 1f, 0, 0, 1f);
                imageViews[index].setImageResource(cartas[index].getImagenRecurso());
                imageViews[index].setAlpha(0f);
                imageViews[index].animate().alpha(1f).setDuration(250).start();
            }, delay);
        }
        handler.postDelayed(onComplete, delay + 250);
    }

    private void actualizarBotonesMano(Button[] botones, boolean enabled, int backgroundColor) {
        for (Button boton : botones) {
            boton.setEnabled(enabled);
            boton.setBackgroundColor(backgroundColor);
        }
    }


    private void actualizarBoton(Button boton, boolean enabled, int textColor, int backgroundColor) {
        boton.setEnabled(enabled);
        boton.setTextColor(textColor);
        boton.setBackgroundColor(backgroundColor);
    }

    private void finalizarRonda(Button[] botonesMano, ImageView[] imageViews) {
        jugada = 0;
        boolMano0 = boolMano1 = boolMano2 = boolMano3 = boolMano4 = false;
        actualizarBotonesMano(botonesMano, false, Color.LTGRAY);
        mensajeGanador.setText(evaluarMano());
        Log.d(TAG, "Mensaje ganador: " + mensajeGanador.getText());
        plataValor.setText(String.valueOf(dinero));
        if(mensajeGanador.getText().equals("+$0")){
            soundPool.play(sonidoIDnada, 1f, 1f, 0, 0, 1f);
        } else if (Objects.equals(tipoMano, "Jotas o mejor") || Objects.equals(tipoMano, "Doble Pareja") || Objects.equals(tipoMano, "Trio")) {
            soundPool.play(sonidoIDpremio, 1f, 1f, 0, 0, 1f);
        } else {
            soundPool.play(sonidoIDpremioGordo, 1f, 1f, 0, 0, 1f);
        }
        Handler handler = new Handler();
        handler.postDelayed(() -> {
            for (ImageView imageView : imageViews) {
                imageView.setImageResource(R.drawable.cover);
            }
            actualizarBoton(subir, true, Color.WHITE, Color.RED);
            actualizarBoton(repartir, true, Color.BLACK, Color.YELLOW);
            mensajeGanador.setText("");
        }, 2000);
    }

    private void subirApuesta() {
        soundPool.play(sonidoIDsubir, 1f, 1f, 0, 0, 1f);
        if (fichasApostadas < 5) {
            fichasApostadas++;
        } else {
            fichasApostadas = 1; // Si llega a 5, vuelve a 1
        }
        apuesta = fichasApostadas * valor_ficha;
        actualizarImagenesApuesta();
        tuApuesta.setText(String.valueOf(apuesta));
    }

    private void actualizarImagenesApuesta() {
        switch (fichasApostadas) {
            case 1:
                valores.setImageResource(R.drawable.valores1);
                break;
            case 2:
                valores.setImageResource(R.drawable.valores2);
                break;
            case 3:
                valores.setImageResource(R.drawable.valores3);
                break;
            case 4:
                valores.setImageResource(R.drawable.valores4);
                break;
            case 5:
                valores.setImageResource(R.drawable.valores5);
                break;
        }
    }

    private String evaluarMano() {
        tipoMano = obtenerTipoMano(cartas);
        String mensaje = obtenerTipoMano(cartas);
        int multiplicador = obtenerMultiplicador(tipoMano);
        int premio = apuesta * multiplicador;
        if (multiplicador > 0) {
            dinero += premio; // Suma el premio si gana
            return "+$" + premio + " con " + tipoMano;
        }
        return mensaje;
    }

    private int obtenerMultiplicador(String tipoMano) {
        switch (tipoMano) {
            case "Escalera Real": return 250;
            case "Escalera de Color": return 50;
            case "Poker": return 25;
            case "Full House": return 9;
            case "Color": return 6;
            case "Escalera": return 4;
            case "Trio": return 3;
            case "Doble Pareja": return 2;
            case "Jotas o mejor": return 1;
            default: return 0; // Si no gana nada
        }
    }

    private String obtenerTipoMano(Carta[] mano) {
        // Ordenamos las cartas por valor (de menor a mayor)
        Arrays.sort(mano, Comparator.comparingInt(Carta::getValor));
        // Comprobamos si es una Escalera Real o una Escalera de Color
        if (esEscalera(mano) && esColor(mano)) {
            if (mano[0].getValor() == 1 && mano[4].getValor() == 13) {
                return "Escalera Real";
            } else {
                return "Escalera de Color";
            }
        }
        // Verificar Poker, Full, Trío, etc.
        if (esPoker(mano)) {
            return "Poker";
        }
        if (esFull(mano)) {
            return "Full House";
        }
        if (esColor(mano)) {
            return "Color";
        }
        if (esEscalera(mano)) {
            return "Escalera";
        }
        if (esTrio(mano)) {
            return "Trio";
        }
        if (esDoblePareja(mano)) {
            return "Doble Pareja";
        }
        if (esJotasOmejor(mano)) {
            return "Jotas o mejor";
        }
        return "+$0";
    }

    private boolean esEscalera(Carta[] mano) {
        int[] valores = new int[5];
        // Extraer valores de las cartas
        for (int i = 0; i < mano.length; i++) {
            valores[i] = mano[i].getValor();
        }
        // Ordenar los valores de menor a mayor
        Arrays.sort(valores);
        // Caso especial: escalera baja con As como 1 (A-2-3-4-5)
        if (valores[0] == 1 && valores[1] == 2 && valores[2] == 3 && valores[3] == 4 && valores[4] == 5) {
            return true;
        }
        // Verificar escalera normal
        boolean escaleraNormal = true;
        for (int i = 0; i < valores.length - 1; i++) {
            if (valores[i] + 1 != valores[i + 1]) {
                escaleraNormal = false;
                break;
            }
        }
        if (escaleraNormal) return true;
        // Caso especial: escalera con As como 14 (10-J-Q-K-A)
        // Convertimos As (1) en 14 para esta verificación
        int[] valoresConAs14 = Arrays.copyOf(valores, 5);
        for (int i = 0; i < valoresConAs14.length; i++) {
            if (valoresConAs14[i] == 1) {
                valoresConAs14[i] = 14;
                break; // Solo hay un As en la mano, así que no necesitamos seguir buscando
            }
        }
        // Ordenar nuevamente para chequear la escalera con As alto
        Arrays.sort(valoresConAs14);
        boolean escaleraConAs14 = true;
        for (int i = 0; i < valoresConAs14.length - 1; i++) {
            if (valoresConAs14[i] + 1 != valoresConAs14[i + 1]) {
                escaleraConAs14 = false;
                break;
            }
        }
        return escaleraConAs14;
    }

    private boolean esColor(Carta[] mano) {
        String palo = mano[0].getPalo();
        for (int i = 1; i < mano.length; i++) {
            if (!mano[i].getPalo().equals(palo)) {
                return false;
            }
        }
        return true;
    }

    private boolean esPoker(Carta[] mano) {
        Map<Integer, Integer> frecuencia = new HashMap<>();
        for (Carta carta : mano) {
            frecuencia.put(carta.getValor(), frecuencia.getOrDefault(carta.getValor(), 0) + 1);
        }
        return frecuencia.containsValue(4);
    }

    private boolean esFull(Carta[] mano) {
        Map<Integer, Integer> frecuencia = new HashMap<>();
        for (Carta carta : mano) {
            frecuencia.put(carta.getValor(), frecuencia.getOrDefault(carta.getValor(), 0) + 1);
        }
        return frecuencia.containsValue(3) && frecuencia.containsValue(2);
    }

    private boolean esTrio(Carta[] mano) {
        Map<Integer, Integer> frecuencia = new HashMap<>();
        for (Carta carta : mano) {
            frecuencia.put(carta.getValor(), frecuencia.getOrDefault(carta.getValor(), 0) + 1);
        }
        return frecuencia.containsValue(3);
    }

    private boolean esDoblePareja(Carta[] mano) {
        Map<Integer, Integer> frecuencia = new HashMap<>();
        for (Carta carta : mano) {
            frecuencia.put(carta.getValor(), frecuencia.getOrDefault(carta.getValor(), 0) + 1);
        }
        int pares = 0;
        for (int count : frecuencia.values()) {
            if (count == 2) pares++;
        }
        return pares == 2;
    }

    private boolean esJotasOmejor(Carta[] mano) {
        int[] valores = new int[14]; // Índices 1-13 representan los valores de las cartas

        for (Carta carta : mano) {
            valores[carta.getValor()]++; // Contamos cuántas veces aparece cada valor
        }
        // Verificamos si hay al menos un par de J, Q, K o A
        return valores[11] >= 2 || valores[12] >= 2 || valores[13] >= 2 || valores[1] >= 2;
    }

}